# WorkBuddy 导入

外层 `fjzm-suite-v4.2.0.zip` 保证三个 Skill 一起下载。请在 WorkBuddy 中依次导入：

1. `fjzm-workbuddy-v4.2.0.zip`
2. `fjzm-texture-workbuddy-v4.2.0.zip`
3. `fjzm-animation-workbuddy-v4.2.0.zip`

每个内层 ZIP 的根目录都直接包含对应的 `SKILL.md`。如果只导入一部分，不要开始完整生产流程。
